# Map Animation

The project create an animated marker on the map to highlight the bus routes between MIT and Harvard.

## Step to Run the Project

Step 1: Click the "Show stops between MIT and Harvard" button to make marker moves from 
MIT and Harvard bus routes.
         
## Future improvement

The project can be further enhanced by adding and finding many different routes between start point 
to end point.
